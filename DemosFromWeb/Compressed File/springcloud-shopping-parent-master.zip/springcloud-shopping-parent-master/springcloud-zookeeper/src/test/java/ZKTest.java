import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author WH
 * @version 1.0
 * @date 2020/2/14 10:33
 */
public class ZKTest {

    //zk连接地址
    private static final String CONNECTSGTRING = "49.233.150.105";
    private static final int SESSIONTIMEOUT = 5000;

    //创建节点
    Map map = new HashMap<String ,String>();
    List<String> list = new ArrayList<>();

}
