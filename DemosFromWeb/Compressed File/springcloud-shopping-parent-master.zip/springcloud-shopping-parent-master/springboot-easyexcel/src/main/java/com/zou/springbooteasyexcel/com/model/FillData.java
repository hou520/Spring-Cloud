package com.zou.springbooteasyexcel.com.model;

import lombok.Data;

/**
 * @author Jiaju Zhuang
 */
@Data
public class FillData {
    private String name;
    private double number;
}
