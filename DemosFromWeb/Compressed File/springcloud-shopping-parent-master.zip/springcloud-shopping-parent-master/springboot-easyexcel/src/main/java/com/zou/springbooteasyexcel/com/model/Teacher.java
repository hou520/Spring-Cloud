package com.zou.springbooteasyexcel.com.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author WH
 * @version 1.0
 * @date 2020/4/22 22:13
 * @Description TODO
 */
@Data
@AllArgsConstructor
public class Teacher {

    private String name;


}
