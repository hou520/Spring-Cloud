package com.shopping.user.controller;

import entity.BaseController;

/**
 * @author WH
 * @version 1.0
 * @date 2019/11/19 21:20
 */
public class UserController extends BaseController {



}
