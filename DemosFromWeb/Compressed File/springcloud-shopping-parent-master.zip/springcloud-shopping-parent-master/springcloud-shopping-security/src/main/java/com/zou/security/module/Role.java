package com.zou.security.module;

import lombok.Data;

/**
 * @author WH
 * @version 1.0
 * @date 2019/12/26 19:30
 */
@Data
public class Role {
    private Integer id;
    private String roleName;
    private String roleDesc;

}
