package com.zou.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zou.entity.User;

/**
 * @author WH
 * @version 1.0
 * @date 2020/5/5 16:16
 * @Description TODO
 */
public interface UserService extends IService<User> {
}
