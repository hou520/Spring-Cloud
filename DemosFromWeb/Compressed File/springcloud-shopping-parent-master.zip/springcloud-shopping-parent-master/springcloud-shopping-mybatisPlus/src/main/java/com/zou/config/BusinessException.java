package com.zou.config;

/**
 * @author WH
 * @version 1.0
 * @date 2020/5/14 0:12
 * @Description TODO
 */
public class BusinessException {
}
