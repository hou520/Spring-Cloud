package com.wlg.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application_Consumer {

    public static void main(String[] args) {
        SpringApplication.run(Application_Consumer.class);
    }
}
