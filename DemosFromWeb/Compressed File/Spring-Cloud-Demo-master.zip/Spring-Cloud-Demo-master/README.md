# Spring-Cloud-Demo
spring cloud示例demo，包含注册中心（eureka），服务提供者，服务消费者，fegin内部调用，ribbon的负载均衡，config配置中心，zuul网关，hystrix熔断器。
