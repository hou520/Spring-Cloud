package com.zwc.configflywayservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigFlywayServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
