package com.zwc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcloudConfigGitClientServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringcloudConfigGitClientServiceApplication.class, args);
    }

}
