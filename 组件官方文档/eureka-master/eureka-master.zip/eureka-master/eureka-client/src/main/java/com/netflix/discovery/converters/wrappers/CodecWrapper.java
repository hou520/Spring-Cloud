package com.netflix.discovery.converters.wrappers;

/**
 * Interface for more useable reference
 *
 * @author David Liu
 */
public interface CodecWrapper extends EncoderWrapper, DecoderWrapper {
}
