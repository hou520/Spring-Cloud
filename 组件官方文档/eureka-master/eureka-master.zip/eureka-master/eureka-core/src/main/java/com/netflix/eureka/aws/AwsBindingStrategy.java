package com.netflix.eureka.aws;

public enum AwsBindingStrategy {
    EIP, ROUTE53, ENI
}
